from puzzle.base_search import BaseSearch
from puzzle.state import State
from puzzle.result import SearchResult

DEFAULT_DEPTH_LIMIT = 50


class DFS(BaseSearch):
    """Busca em profundidade com limite máximo de profundidade."""

    def __init__(self, depth_limit: int = DEFAULT_DEPTH_LIMIT):
        self.depth_limit = depth_limit

    def search(self, initial: State) -> SearchResult:
        frontier = [initial]
        best_depth = {initial.tiles: 0}
        nodes_expanded = 0
        nodes_generated = 1
        max_frontier_size = 1

        while frontier:
            current = frontier.pop()
            if current.is_goal:
                return SearchResult(current, nodes_expanded, nodes_generated,
                                    max_frontier_size, current.cost)
            if current.cost >= self.depth_limit:
                continue

            nodes_expanded += 1
            # A ordem invertida mantém a ordem natural dos movimentos na pilha.
            for child in reversed(current.neighbors()):
                depth = child.cost
                previous = best_depth.get(child.tiles)
                if previous is None or depth < previous:
                    best_depth[child.tiles] = depth
                    frontier.append(child)
                    nodes_generated += 1
            max_frontier_size = max(max_frontier_size, len(frontier))

        return SearchResult(None, nodes_expanded, nodes_generated, max_frontier_size, 0)
